# $NPC BRAND GUIDE & MEME CREATION TOOLKIT
## Visual Identity, Design System & Content Creation

---

## 🎨 BRAND IDENTITY

### Core Brand Concept

**Philosophy:**
Self-aware meta commentary on crypto culture through the lens of video game NPCs. We embrace the scripted, repetitive nature of both gaming NPCs and crypto traders.

**Personality:**
- Self-aware but not cynical
- Ironic but not mean
- Meta but accessible
- Funny but not stupid
- Gaming-savvy but crypto-native

**Target Audience:**
- 18-35 year old gamers
- Crypto natives (especially meme coin traders)
- Meta/irony humor appreciators
- Self-aware individuals
- Gaming and crypto culture crossover

---

## 🎨 COLOR PALETTE

### Primary Colors

**NPC Gray**
```
HEX: #808080
RGB: 128, 128, 128
CMYK: 0, 0, 0, 50
USE: Primary brand color, NPC character, buttons, accents
FEELING: Neutral, systematic, robotic, archetypal
```

**Dark Background**
```
HEX: #0a0a0a
RGB: 10, 10, 10
CMYK: 0, 0, 0, 96
USE: Website backgrounds, cards, containers
FEELING: Deep, simulation, void, matrix
```

**Darker Background**
```
HEX: #050505
RGB: 5, 5, 5
CMYK: 0, 0, 0, 98
USE: Sections, depth, shadows, contrast
FEELING: Ultimate depth, simulation layers
```

### Secondary Colors

**Light Gray (Text)**
```
HEX: #c0c0c0
RGB: 192, 192, 192
CMYK: 0, 0, 0, 25
USE: Body text, descriptions, secondary elements
```

**Medium Gray (Accent)**
```
HEX: #666666
RGB: 102, 102, 102
CMYK: 0, 0, 0, 60
USE: Borders, dividers, subtle accents
```

**White (Highlights)**
```
HEX: #ffffff
RGB: 255, 255, 255
CMYK: 0, 0, 0, 0
USE: Headlines, important text, CTAs on hover
```

### Color Usage Guidelines

**DO:**
✅ Keep design predominantly monochromatic
✅ Use grays for 90% of design
✅ White for important elements only
✅ Maintain minimalist aesthetic
✅ Embrace the "bland NPC" look

**DON'T:**
❌ Add bright colors (ruins NPC aesthetic)
❌ Use gradients (too fancy for NPCs)
❌ Over-complicate with multiple colors
❌ Stray from gray color scheme
❌ Make it too "designed"

---

## 📝 TYPOGRAPHY

### Primary Font: Courier New

**Why Courier?**
- Monospace = systematic/coded feeling
- Terminal/programming aesthetic
- NPCs are programmed entities
- Retro gaming vibes
- Universally available

**Usage:**
```
HEADLINES: Courier New, Bold, 48-72pt
BODY TEXT: Courier New, Regular, 16-18pt
CAPTIONS: Courier New, Regular, 12-14pt
BUTTONS: Courier New, Bold, 14-16pt, UPPERCASE
```

**Alternative Fonts (If Needed):**
- **Consolas** (Windows)
- **Monaco** (Mac)
- **Source Code Pro** (Web)
- **Roboto Mono** (Backup)

### Typography Rules

**DO:**
✅ Use monospace fonts exclusively
✅ Keep letter-spacing tight
✅ ALL CAPS for emphasis (not bold)
✅ Maintain terminal/code aesthetic

**DON'T:**
❌ Use serif fonts
❌ Use script/handwritten fonts
❌ Excessive font weights
❌ Decorative fonts

---

## 🤖 MASCOT: THE GRAY MAN

### Character Design

**Physical Appearance:**
```
SHAPE: Simple humanoid silhouette
COLOR: NPC Gray (#808080)
FACE: 
  - Two dot eyes (black circles)
  - Single line mouth (horizontal)
  - No nose, no details
HEIGHT: Proportional human
STYLE: Flat, 2D, minimal, iconic
```

**Variations:**

**Standing Pose (Default):**
- Straight standing
- Arms at sides
- Neutral expression
- Slightly robotic posture

**Merchant Pose:**
- Behind counter/table
- Hands together
- Generic welcoming stance

**Walking Cycle:**
- Stiff animation
- Repetitive loop
- Mechanical movement

**Idle Animation:**
- Minimal movement
- Subtle breathing
- Occasional blink
- Shift weight foot-to-foot

### Mascot Usage Guidelines

**DO:**
✅ Keep design simple always
✅ Maintain gray color
✅ Use in various scenarios
✅ Show in NPC-like poses
✅ Reference gaming NPCs

**DON'T:**
❌ Add too many details
❌ Change the core design
❌ Make expressive/emotional
❌ Over-animate
❌ Add colors

---

## 🎮 DESIGN ELEMENTS

### UI Components

**Dialogue Box:**
```
STYLE: Classic RPG dialogue box
BORDER: 2px solid #808080
BACKGROUND: rgba(10, 10, 10, 0.9)
PADDING: 20px
TEXT: #c0c0c0, Courier New
CORNER: Optional arrow pointing to character
```

**Example:**
```
┌─────────────────────────────────┐
│ Greetings, traveler.            │
│                                 │
│ I have information about $NPC   │
│ that may interest you...        │
│                                 │
│ > Tell me more                  │
│ > Buy $NPC                      │
│ > [Leave]                       │
└─────────────────────────────────┘
```

**Buttons:**
```
DEFAULT STATE:
- Background: #808080
- Text: #0a0a0a
- Border: none
- Padding: 16px 32px
- Font: Courier New, Bold, UPPERCASE

HOVER STATE:
- Background: #ffffff
- Text: #0a0a0a
- Transform: translateY(-2px)
- Box-shadow: 0 4px 12px rgba(128,128,128,0.3)

ACTIVE STATE:
- Transform: translateY(0)
- Box-shadow: none
```

**Cards:**
```
BACKGROUND: rgba(128, 128, 128, 0.05)
BORDER: 1px solid rgba(128, 128, 128, 0.2)
PADDING: 30px
HOVER: 
  - Background: rgba(128, 128, 128, 0.1)
  - Border: 1px solid #808080
  - Transform: translateY(-4px)
```

**Icons:**
```
STYLE: Simple, minimal, 2D
COLOR: #808080 or #c0c0c0
SIZE: 24x24px, 48x48px, 64x64px
FORMAT: SVG preferred
EXAMPLES:
  - 🤖 Robot/NPC head
  - 💬 Dialogue bubble
  - 🎮 Game controller
  - 📊 Chart icon
  - 💎 Diamond
```

---

## 📸 SOCIAL MEDIA TEMPLATES

### Twitter Post Templates

**Standard Meme (1200x675px):**
```
LAYOUT:
┌─────────────────────────────────┐
│  [NPC character or meme image]  │
│                                 │
│  [PUNCHY TEXT IN COURIER]       │
│                                 │
│  $NPC | Just following script   │
└─────────────────────────────────┘

ELEMENTS:
- Gray background or relevant image
- Bold white/gray text
- Small $NPC logo/watermark
- Minimal design
```

**Quote Template (1200x675px):**
```
LAYOUT:
┌─────────────────────────────────┐
│                                 │
│    "Greetings, traveler."       │
│                                 │
│    - Every NPC Ever             │
│                                 │
│    $NPC | NonPumpableCoin       │
│                                 │
└─────────────────────────────────┘

SPECS:
- Dark gray background (#0a0a0a)
- Quote in large Courier New
- Attribution below
- Centered layout
```

**Dialogue Box Template (1200x675px):**
```
LAYOUT: RPG-style dialogue interaction
BACKGROUND: Game screenshot or gray gradient
OVERLAY: Dialogue box at bottom
TEXT: NPC dialogue about $NPC
OPTIONS: Multiple choice responses
```

### Instagram Templates

**Square Post (1080x1080px):**
```
GRID LAYOUT:
Top 1/3: NPC character
Middle 1/3: Main message
Bottom 1/3: $NPC branding

STYLE:
- Monochromatic
- High contrast
- Bold typography
- Minimal elements
```

**Story Template (1080x1920px):**
```
VERTICAL LAYOUT:
Header: "NPC.exe"
Main: Large text/meme
Footer: @NPCcoin + CA

INTERACTIVE:
- Poll stickers
- Quiz stickers  
- Question stickers
- All in theme
```

### Discord Embeds

**Announcement Embed:**
```json
{
  "color": 8421504,  // #808080 in decimal
  "title": "📢 NPC ANNOUNCEMENT",
  "description": "Your dialogue options have been updated...",
  "thumbnail": {
    "url": "npc_icon.png"
  },
  "fields": [
    {
      "name": "Quest",
      "value": "Check chart 100 times",
      "inline": true
    }
  ],
  "footer": {
    "text": "Just following the script"
  }
}
```

---

## 🎬 MEME CREATION GUIDE

### Meme Categories

#### 1. Classic NPC Behavior
**Examples:**
- Standing in same spot forever
- Repeating same dialogue
- Generic greetings
- Limited response options
- Scripted reactions

**Template Ideas:**
```
IMAGE: NPC standing by tree for 10 years
TEXT: "Still here. Still holding $NPC. Just following the script."

IMAGE: Skyrim vendor
TEXT: "I have coin opportunities if you have time"
      "$NPC | Always open for business"

IMAGE: NPC with ! above head
TEXT: "New quest: Buy $NPC"
```

#### 2. Crypto NPC Parallels
**Examples:**
- Everyone says same thing
- Follow same patterns
- Predictable responses
- Herd mentality
- Scripted behavior

**Template Ideas:**
```
IMAGE: Drake meme
REJECT: "Having original trading strategy"
PREFER: "Copying whatever CT says"
FOOTER: "$NPC - We're all NPCs anyway"

IMAGE: Galaxy brain expanding
LEVEL 1: "Trade based on fundamentals"
LEVEL 2: "Trade based on technicals"
LEVEL 3: "Trade based on vibes"
LEVEL 4: "Just follow the script"
FOOTER: "$NPC"
```

#### 3. Self-Aware Meta Commentary
**Examples:**
- Knowing you're an NPC
- Breaking the 4th wall
- Simulation awareness
- Pattern recognition
- Meta humor

**Template Ideas:**
```
IMAGE: Morpheus offering pills
RED PILL: "See that you're an NPC"
BLUE PILL: "Keep following the script"
TEXT: "Both lead to buying $NPC"

IMAGE: "Are we in a simulation?" chart
EVIDENCE: 
- Everyone says same phrases ✓
- Repetitive patterns ✓
- Scripted responses ✓
- NPCs everywhere ✓
CONCLUSION: "$NPC confirms simulation"
```

#### 4. Gaming References
**Examples:**
- Specific game NPCs
- Quest systems
- Dialogue trees
- Glitches
- Easter eggs

**Template Ideas:**
```
IMAGE: Skyrim guard
TEXT: "I used to be a trader like you..."
      "Then I took a dump to the portfolio"
FOOTER: "$NPC - Respawn and try again"

IMAGE: GTA NPC walking into wall
TEXT: "Me trying to time the market"
FOOTER: "$NPC - Flawless AI"

IMAGE: Oblivion NPC stare
TEXT: "POV: You're trying to explain $NPC to normies"
```

#### 5. Holder Motivation
**Examples:**
- Diamond hands
- Community strength
- HODL mentality
- Belief in project
- Long-term vision

**Template Ideas:**
```
IMAGE: NPC standing guard
TEXT: "Day 47 of holding $NPC"
      "Still here. Still following script."
      "NPCs don't quit."

IMAGE: Chad meme
TEXT: "Sells at first dip" vs "Follows the script"
FOOTER: "$NPC - Diamond Hand NPCs"
```

### Meme Best Practices

**DO:**
✅ Keep text minimal and punchy
✅ Use high contrast for readability
✅ Include $NPC branding subtly
✅ Make it shareable (relatability)
✅ Stay on-brand with NPC theme
✅ Reference gaming culture
✅ Self-aware humor

**DON'T:**
❌ Over-explain the joke
❌ Use too much text
❌ Make it too complex
❌ Stray from NPC concept
❌ Be mean-spirited
❌ Copy other coins exactly
❌ Low quality images

### Viral Meme Formula

```
RELATABLE SITUATION
+
NPC/GAMING REFERENCE
+
SELF-AWARE TWIST
+
$NPC BRANDING
=
VIRAL MEME
```

**Example:**
```
Situation: "Checking crypto portfolio every 5 minutes"
Reference: "NPC behavior: patrol same area repeatedly"
Twist: "We're all programmed this way"
Branding: "$NPC - Just following the script"
Result: VIRAL
```

---

## 🛠️ CREATION TOOLS

### Recommended Software

**Free Tools:**
```
CANVA:
- Templates available
- Easy meme creation
- Social media sizes
- PNG export

FIGMA:
- Professional design
- Collaboration
- Free tier robust
- Vector graphics

GIMP:
- Open source Photoshop
- Advanced editing
- Free forever
- Cross-platform

PHOTOPEA:
- Browser-based
- Photoshop-like
- No installation
- Free
```

**Paid Tools (If Budget):**
```
ADOBE PHOTOSHOP:
- Industry standard
- Advanced features
- $20-50/month

ADOBE ILLUSTRATOR:
- Vector graphics
- Logo creation
- Professional output
```

**AI Tools:**
```
MIDJOURNEY:
- AI image generation
- NPC character variations
- Meme backgrounds
- $10-30/month

DALL-E:
- AI image creation
- Specific prompts
- Custom scenarios
```

### Quick Meme Generators

**imgflip.com:**
- Fast meme creation
- Popular templates
- Free watermark (removable paid)
- Share directly

**kapwing.com:**
- Video editing
- Meme maker
- Resize tools
- Collaboration

**remove.bg:**
- Background removal
- Clean NPC character
- API available
- Free tier

---

## 📐 ASSET SPECIFICATIONS

### Logo Files Needed

**Primary Logo:**
```
FILE: npc_logo_primary.png
SIZE: 1000x1000px
FORMAT: PNG with transparency
USE: Social media, website, general branding
```

**Logo Variations:**
```
npc_logo_white.png (white version for dark bg)
npc_logo_gray.png (gray version)
npc_logo_small.png (512x512 for icons)
npc_logo_favicon.ico (32x32 for website)
```

**Wordmark:**
```
FILE: npc_wordmark.png
CONTENT: "$NPC | Non-Pumpable Coin"
FORMAT: PNG with transparency
SIZES: 
  - 2000x400px (high res)
  - 1000x200px (standard)
  - 500x100px (small)
```

### Social Media Sizes

**Twitter:**
```
Profile Picture: 400x400px
Header: 1500x500px
In-feed Image: 1200x675px
Card Image: 800x418px
```

**Instagram:**
```
Profile Picture: 320x320px
Square Post: 1080x1080px
Portrait Post: 1080x1350px
Story: 1080x1920px
```

**Discord:**
```
Server Icon: 512x512px
Server Banner: 960x540px
Emoji: 128x128px
Stickers: 320x320px
```

**Telegram:**
```
Group Photo: 640x640px
Channel Photo: 640x640px
Stickers: 512x512px
```

**Website:**
```
Hero Image: 1920x1080px
Favicon: 32x32px
OG Image: 1200x630px
```

---

## 🎨 BRAND APPLICATIONS

### Website Elements

**Hero Section:**
```
BACKGROUND: Dark gradient (#0a0a0a to #050505)
CHARACTER: Large NPC Gray Man (animated float)
HEADLINE: "NON-PUMPABLE COIN" (white, 64px)
TICKER: "$NPC" (gray, 48px)
TAGLINE: "Just following the script" (gray, 24px)
CTA: Gray button with white text
```

**Feature Cards:**
```
LAYOUT: Grid of 3-6 cards
BACKGROUND: rgba(128, 128, 128, 0.05)
BORDER: 1px solid rgba(128, 128, 128, 0.2)
ICON: Simple gray icon (48x48)
TITLE: White, 24px, Courier New
TEXT: Gray, 16px, Courier New
HOVER: Lift + border glow
```

**Footer:**
```
BACKGROUND: #050505
TEXT: #666
LINKS: #808080, hover → #ffffff
LAYOUT: Centered, minimal
SOCIAL: Icon links (gray → white on hover)
```

### Marketing Materials

**Flyer/Poster:**
```
SIZE: 8.5" x 11" or A4
LAYOUT:
  - Top: Large NPC character
  - Middle: Key message
  - Bottom: $NPC branding + links
STYLE: High contrast, minimal
PRINT: Grayscale friendly
```

**Business Card (If Needed):**
```
FRONT:
  - NPC logo
  - "$NPC"
  - "Just following the script"
BACK:
  - Contract address
  - Website
  - Social links
PRINT: Grayscale, matte finish
```

**Merch Designs:**
```
T-SHIRT:
  - Front: NPC character
  - Back: "Just following the script"
  - Color: Gray on black/white

HOODIE:
  - Chest: Small $NPC logo
  - Back: Large dialogue box design
  - Color: Gray/Black

HAT:
  - Embroidered NPC icon
  - "$NPC" text
  - Color: Gray/Black
```

---

## 🎯 CONTENT CREATION WORKFLOW

### Daily Content Production

**Morning (9-11 AM EST):**
```
1. Check trending topics (Twitter, Reddit)
2. Create 2-3 memes (gaming + crypto angle)
3. Schedule posts for peak hours
4. Engage with community comments
5. Retweet holder content
```

**Afternoon (1-3 PM EST):**
```
1. Monitor chart/community sentiment
2. Create reaction memes if needed
3. Engage with other crypto projects
4. Discord community interaction
5. Plan evening content
```

**Evening (6-8 PM EST):**
```
1. Post prime-time meme
2. Run community engagement (poll/quiz)
3. Share holder highlights
4. Prepare next day's content
5. Analytics review
```

**Night (10-11 PM EST):**
```
1. Final meme of the day
2. Good night message (NPC style)
3. Schedule overnight content
4. Team debrief
5. Tomorrow planning
```

### Weekly Content Calendar

**Monday:**
- Motivation memes
- Week preview
- Quest announcements

**Tuesday:**
- Educational content (how NPCs work)
- Holder spotlights
- Chart analysis

**Wednesday:**
- Hump day humor
- Community contests
- Meme competitions

**Thursday:**
- Throwback memes
- Gaming references
- Partnership announcements

**Friday:**
- Weekend hype
- Community highlights
- Fun/chill content

**Saturday:**
- User-generated content showcase
- Casual engagement
- Organic growth

**Sunday:**
- Weekly recap
- Top memes review
- Next week tease

---

## 🎁 DOWNLOADABLE ASSET PACK

### Package Contents

**Templates Folder:**
```
/templates
  ├── twitter_meme_template.psd
  ├── instagram_post_template.psd
  ├── instagram_story_template.psd
  ├── discord_embed_template.json
  └── dialogue_box_template.png
```

**Logos Folder:**
```
/logos
  ├── npc_logo_primary.png
  ├── npc_logo_white.png
  ├── npc_logo_gray.png
  ├── npc_logo_small.png
  ├── npc_logo.svg
  └── npc_wordmark.png
```

**Characters Folder:**
```
/characters
  ├── npc_standing.png
  ├── npc_merchant.png
  ├── npc_walking.gif
  ├── npc_idle.gif
  └── npc_variations/ (multiple poses)
```

**Meme Templates:**
```
/meme_templates
  ├── drake_npc.png
  ├── galaxy_brain_npc.png
  ├── dialogue_options.png
  ├── distracted_npc.png
  └── expanding_brain_npc.png
```

**Social Assets:**
```
/social
  ├── twitter_header.png
  ├── discord_banner.png
  ├── telegram_photo.png
  └── profile_pictures/ (various sizes)
```

---

## 📋 BRAND CHECKLIST

### Every Design Should:
```
☑️ Use Courier New or monospace font
☑️ Stick to gray color palette
☑️ Include NPC character or reference
☑️ Maintain minimal aesthetic
☑️ Be on-brand with theme
☑️ Include subtle $NPC branding
☑️ Be shareable/viral-optimized
☑️ Pass the "NPC test" (looks robotic/systematic)
```

### Quality Control:
```
ASK:
❓ Does this look like an NPC would make it?
❓ Is it self-aware and meta?
❓ Would gamers get the reference?
❓ Is it shareable?
❓ Does it serve a purpose?
❓ Is branding clear but not obnoxious?

IF NO TO ANY → REVISE
```

---

*End of Brand Guide*

**FINAL REMINDER:**

The $NPC brand is about:
- Embracing systematic, robotic aesthetics
- Self-aware meta commentary
- Gaming culture integration
- Minimal, iconic design
- Community-driven content

We're not trying to be the flashiest.
We're trying to be the most self-aware.

Keep it gray. Keep it simple. Keep it NPC.

Just follow the script. 🤖
